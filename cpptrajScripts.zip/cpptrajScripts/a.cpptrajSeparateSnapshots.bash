if [ $# != 1 ]; then
    echo "Usage: $0 folderList.txt"
    exit
fi

folder=$1

writeCpptrajInput () {
folder=$1
echo "
parm CPLX.parm7
trajin produ.nc 1 10000 50
trajout ../$folder-snapshots/ss multi pdb
" > cpptrajSeparate.in
}

for folder in `cat folderList.txt`
do
    echo $folder
    mkdir $folder-snapshots/
    cd $folder
    writeCpptrajInput $folder
    cpptraj -i cpptrajSeparate.in
    cd ../
done
    
    
    
    
