if [ $# != 4 ]; then
    echo "Usage: $0 simReplicates.txt alignerInputs.txt inputFolder alignmentResidues.txt"
    exit
fi
simulationReplicates=$1
alignerInputs=$2
inputFolder=$3
alignmentResidues=$4
for alignmentResidue in `cat $alignmentResidues`
do
    echo "Doing residue $alignmentResidue"
    sed "s/VMB_RESIDUE/$alignmentResidue/g" $alignerInputs > $alignmentResidue.alignerInputs.txt
    rm -rf $alignmentResidue.outputs
    mkdir $alignmentResidue.outputs
    bash a.aligner_WithLimit.sh $simulationReplicates $inputFolder $alignmentResidue.outputs $alignmentResidue.alignerInputs.txt
done
